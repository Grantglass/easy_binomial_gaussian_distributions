from setuptools import setup

setup(name='easy_binomial_gaussian_distributions',
      version='1.0',
      description='Easy Gaussian and Binomial distributions',
      packages=['easy_binomial_gaussian_distributions'],
      author='Grant Glass',
      zip_safe=False)
